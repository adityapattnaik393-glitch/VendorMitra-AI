# Run from backend/ in PowerShell:   .\setup.ps1
# If blocked: Set-ExecutionPolicy -Scope Process Bypass
$ErrorActionPreference = "Stop"
if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
# CPU-only PyTorch (small) - avoids the huge CUDA download that kept failing
.\.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env; Write-Host "Created .env - open it and paste your IBM key + project id" }
Write-Host "`nDone. Next:  .\.venv\Scripts\Activate.ps1 ; python -m app.check_granite"
