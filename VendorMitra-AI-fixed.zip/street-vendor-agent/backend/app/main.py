from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from app import granite
from app.agent import ask_vendor_mitra
from app.rag import indexed_chunks, ingest_documents

app = FastAPI(title="VendorMitra AI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class VendorProfile(BaseModel):
    business_name: str | None = None
    business_type: str | None = None
    products: list[str] = Field(default_factory=list, max_length=20)
    location: str | None = None
    preferred_language: str | None = None


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=4000)
    task: Literal[
        "general",
        "business_profile",
        "upi_setup",
        "local_seo",
        "customer_engagement",
    ] = "general"
    vendor: VendorProfile | None = None


@app.get("/")
def home():
    return {
        "message": "VendorMitra AI is running"
    }


@app.get("/health")
def health():
    """Quick status without calling IBM: config + how many chunks are indexed."""
    problems = granite.config_problems()
    try:
        chunks = indexed_chunks()
    except Exception as exc:  # chromadb not installed / DB problem
        chunks = f"error: {exc}"
    return {
        "granite_configured": not problems,
        "problems": problems,
        "model": granite.GRANITE_MODEL_ID,
        "region": granite.IBM_REGION,
        "indexed_chunks": chunks,
    }


@app.get("/granite/test")
def granite_test():
    """Makes one real call to IBM Granite and reports success or the exact error."""
    try:
        answer = granite.generate_answer(
            question="Reply with exactly: Granite is working.",
            context="(none)",
            max_tokens=30,
        )
    except granite.GraniteError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return {"ok": True, "model": granite.GRANITE_MODEL_ID, "answer": answer}


@app.post("/ingest")
def ingest():
    try:
        chunks = ingest_documents()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"message": "Documents indexed successfully", "chunks": chunks}


@app.post("/chat")
def chat(request: ChatRequest):
    vendor_profile = (
        request.vendor.model_dump(exclude_none=True, exclude_defaults=True)
        if request.vendor
        else None
    )
    try:
        return ask_vendor_mitra(
            request.question,
            task=request.task,
            vendor_profile=vendor_profile,
        )
    except granite.GraniteError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
