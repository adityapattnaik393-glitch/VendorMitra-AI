"""Diagnostic: is IBM Granite really wired up?   Run:  python -m app.check_granite"""
import requests

from app import granite


def _step(ok: bool, text: str):
    print(("  [PASS] " if ok else "  [FAIL] ") + text)
    return ok


def main() -> int:
    print(f"Region : {granite.IBM_REGION}  ({granite.WATSONX_URL})")
    print(f"Model  : {granite.GRANITE_MODEL_ID}\n")

    print("1) .env values")
    problems = granite.config_problems()
    if not _step(not problems, "IBM_API_KEY and IBM_PROJECT_ID are set" if not problems else "; ".join(problems)):
        return 1

    print("2) IBM IAM login")
    try:
        granite.get_iam_token(force_refresh=True)
        _step(True, "API key accepted, bearer token received")
    except granite.GraniteError as exc:
        _step(False, str(exc))
        return 1

    print("3) Granite models served in your region")
    try:
        r = requests.get(
            f"{granite.WATSONX_URL}/ml/v1/foundation_model_specs",
            params={"version": "2024-09-16", "limit": 200},
            timeout=30,
        )
        r.raise_for_status()
        models = [m for m in r.json().get("resources", []) if "granite" in m.get("model_id", "")]
        for m in sorted(models, key=lambda x: x["model_id"]):
            funcs = {f.get("id") for f in m.get("functions", [])}
            states = {s.get("id") for s in m.get("lifecycle", [])}
            tag = "withdrawn" if "withdrawn" in states else "deprecated" if "deprecated" in states else "available"
            chat = "chat" if "text_chat" in funcs else "no-chat"
            print(f"      {m['model_id']:<40} {tag:<11} {chat}")
        ids = {m["model_id"] for m in models}
        if ids and granite.GRANITE_MODEL_ID not in ids:
            print(f"  [WARN] '{granite.GRANITE_MODEL_ID}' is NOT in this list -> set IBM_MODEL_ID in .env "
                  "to one that is 'available' + 'chat'.")
    except Exception as exc:  # listing is informational only
        print(f"  [WARN] could not list models: {exc}")

    print("4) Real Granite call")
    try:
        answer = granite.generate_answer(
            question="Reply with exactly: Granite is working.",
            context="(none)", task="general", max_tokens=30,
        )
        _step(True, f"Granite answered: {answer!r}")
    except granite.GraniteError as exc:
        _step(False, str(exc))
        return 1

    print("\nAll good - IBM Granite is integrated and responding.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
